package com.imooc.enums;

/**
 * Created by 廖师兄
 * 2017-07-16 18:16
 */
public interface CodeEnum {
    Integer getCode();
}
